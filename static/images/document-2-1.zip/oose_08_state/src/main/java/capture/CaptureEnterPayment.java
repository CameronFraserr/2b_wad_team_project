package capture;

import java.util.HashMap;

import StudentInformation.StudentPaymentRecord;
import StudentInformation.StudentRecord;
import StudentInformation.StudentRegistrationRecord;
import StudentInformation.StudentStageRecord;

public class CaptureEnterPayment extends CaptureStage{
	
	protected String cardTypeQuestion = "Enter your card type";
    protected String cardNumberQuestion = "Enter your card number";
    
	public CaptureEnterPayment(StudentRecord studentRecord) {
		super(studentRecord);
	}

	@Override
	HashMap<String, String> getQuestions() {
		HashMap<String, String> questions = new HashMap<String, String>();
        questions.put(cardTypeQuestion,"");
        questions.put(cardNumberQuestion,"");
        return questions;
	}

	@Override
	StudentStageRecord getStudentStage(HashMap<String, String> answers) {
		StudentPaymentRecord studentPayment = null;
        if (answers.get(cardTypeQuestion).length() > 0
        && answers.get(cardNumberQuestion).length() > 0)
        {
        	studentPayment = new StudentPaymentRecord(answers.get(cardTypeQuestion), answers.get(cardNumberQuestion), studentRecord);
            studentRecord.setStudentPaymentRecord(studentPayment);
        }
        return studentPayment;
	}
	
}
