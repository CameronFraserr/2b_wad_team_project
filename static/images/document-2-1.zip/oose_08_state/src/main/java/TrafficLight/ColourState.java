package TrafficLight;

public interface ColourState {

    public void setState( );

    public String getColour();
}
