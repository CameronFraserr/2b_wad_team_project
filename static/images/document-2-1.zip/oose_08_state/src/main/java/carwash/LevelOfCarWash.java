package carwash;

public enum LevelOfCarWash {
    SILVER, GOLD, PLATINUM;
}
