package carwash;
public interface WashState {

    public void setState();

    public String getState();
}

