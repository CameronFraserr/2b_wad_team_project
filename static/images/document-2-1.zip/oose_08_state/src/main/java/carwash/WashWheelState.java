package carwash;
public class WashWheelState implements WashState {

    private CarWash carWash;

    public WashWheelState(CarWash carWash){
        this.carWash = carWash;
    }

    private void washWheel(){
        System.out.println("Wash wheels");
    }

    public void setState(){
        washWheel();
        this.carWash.setWashState(new WashFinishState(this.carWash));
    }

    public String getState(){
        return CarWashStage.WHEEL.getStage();
    }
}
