package State;

import StudentInformation.StudentRecord;

public class ApplicationState implements State{
    @Override
    public void setState(StudentRecord studentRecord) {
    	if (studentRecord.getStudentID().length()>0&&studentRecord.getFirstName().length()>0&&studentRecord.getEmail().contains("@")) {
    		studentRecord.setState(new RegistrationState());
    	}
    }

    @Override
    public StudentStateType getState() {
        return StudentStateType.APPLICATION;
    }
}
