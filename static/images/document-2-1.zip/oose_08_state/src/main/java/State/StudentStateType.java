package State;

public enum StudentStateType {

    APPLICATION, REGISTRATION, FINANCIAL, ACTIVE, WITHDRAWN, ENTER_PAYMENT
}
