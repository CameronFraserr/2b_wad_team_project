package State;

import StudentInformation.StudentRecord;
import capture.CaptureRegistration;

public class RegistrationState implements State{
	
	@Override
	public void setState(StudentRecord studentRecord) {
		CaptureRegistration captureRegistration =  new CaptureRegistration(studentRecord);
		if(captureRegistration.stage()!=null) {
			studentRecord.setState(new FinancialState());
		}
	}

	@Override
	public StudentStateType getState() {
        return StudentStateType.REGISTRATION;
	}

	

}
