package State;

import StudentInformation.StudentRecord;
import capture.CaptureFinancial;

public class FinancialState implements State {

	@Override
	public void setState(StudentRecord studentRecord) {
		CaptureFinancial captureFinancial = new CaptureFinancial(studentRecord);
		if(studentRecord.getStudentFinanceRecord().getHowToPay() == "SAAS") {
			studentRecord.setState(new ActiveState());
		}
		else if(captureFinancial.stage() != null){
			studentRecord.setState(new EnterPaymentState());
		}

	}

	@Override
	public StudentStateType getState() {
		return StudentStateType.FINANCIAL;
	}

}
