package State;

import StudentInformation.StudentRecord;
import capture.CaptureEnterPayment;

public class EnterPaymentState implements State{

	@Override
	public void setState(StudentRecord studentRecord) {
		CaptureEnterPayment captureEnterPayment = new CaptureEnterPayment(studentRecord);
		if(captureEnterPayment != null) {
			studentRecord.setState(new ActiveState());
		}
	}

	@Override
	public StudentStateType getState() {
		return StudentStateType.ENTER_PAYMENT;
	}

}
