package State;

import StudentInformation.StudentRecord;

public class ActiveState implements State {

	@Override
	public void setState(StudentRecord studentRecord) {
		System.out.println("congrats bestie");
	}

	@Override
	public StudentStateType getState() {
		// TODO Auto-generated method stub
		return null;
	}

}
