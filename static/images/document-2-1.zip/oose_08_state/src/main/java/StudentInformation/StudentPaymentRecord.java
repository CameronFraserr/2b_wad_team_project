package StudentInformation;

public class StudentPaymentRecord extends StudentStageRecord{
	private String cardType;
    private String cardNumber;
    
	public StudentPaymentRecord(String cardType, String cardNumber, StudentRecord studentRecord) {
		super(studentRecord);
		this.cardType = cardType;
        this.cardNumber = cardNumber;
	}
	
	public String getCardType() {
        return cardType;
    }

    public String cardNumber() {
        return cardNumber;
    }

}
