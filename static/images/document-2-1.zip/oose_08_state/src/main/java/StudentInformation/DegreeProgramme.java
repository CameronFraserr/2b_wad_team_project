package StudentInformation;

public class DegreeProgramme {

    private String name;

    public DegreeProgramme(String name) {
        this.name = name;
    }

    public String getName() {
        return name;
    }
}
