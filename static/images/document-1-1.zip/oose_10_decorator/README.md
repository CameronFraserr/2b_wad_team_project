## Setup
* see 
* Clone your copy using gitbash
* Open using existing files in your IDE

## Overview
* You have been given the start of some simple levelGenerator code developed following the decorator pattern. The code has a LevelGenerator at it's base, concrete levels (A beach, forest and desert), an abstarct decorator, and concrete decorators that will add features to the generateLevel method when it is called. For example, if you make a new BeachLevel and decorate it with wolves:

LevelGenerator lg = new WolfDecorator(new BeachLevel());
System.out.println(lg.generateLevel());

You should see:

You see a beach around you
Beyond that you see wolves


* You clean code and easy your solution to maintain will be graded. This is a link to a style guide that will be used [https://stgit.dcs.gla.ac.uk/DerekSomerville/javagetstarted/-/wikis/home/Style_Guide](https://stgit.dcs.gla.ac.uk/DerekSomerville/javagetstarted/-/wikis/home/Style_Guide)

## Task One
* Write a main method that gets the beach and wolves decorator working so that you can make a string that describes the level with the generateLevel() method.
* Something is wrong with the output being generated -= it's the wrong way around! Find out why that's happening and fix the mistake!

## Task Two
* Get the ForestLevel.java class to work with the wolves decorator in the same way - it should start it's generate level with the line:
  * "You see a beach around you \n"
* Create your own DesertLevel.java class from scratch
  * "You see a desert around you \n"

## Task Three
* Make a TreasureDecorator.java class to act as a decorator. It should add the following text when the level is being generated:
  * "Beyond that you see treasure \n"

## Task Four - A new method
* Add in a second function that will work out how hard the level is going to be called calculateChallenge which shoud return an integer represnting the challenge of the level when called.
* Challenge starts at 0 and increases in the following ways:
  * Beach: +10
  * Forest: +20
  * Desert: +30

* Each addition of decorators to the level will add challenge in the following way:
  * Wolves: +20
  * Treasure: -10


## Task Five - Snakes
Adding in additional functionality like this is tricky and takes some consideration to work oput where ionformation should be stored and set in the decorator pattern

* Create a third level decorator, SnakeDecorator.java, which adds the following whenj you genertaeLevel():
  * "Beyond that you see a snake \n"

* Snake's are tricky to deal with because their difficulty varies depending on where they are so the calculateChallenge will need to perform differently depending on which type of environment you are in:
  * Beach: +20
  * Desert: +30
  * Forest: +40

You will need to modify other code in other classes to get this to work!