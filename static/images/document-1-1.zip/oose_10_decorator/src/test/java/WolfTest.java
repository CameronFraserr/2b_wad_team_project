import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class WolfTest
{
	LevelGenerator lg = new WolfDecorator(new BeachLevel());
	
	@Test
	void wolfTest()
	{
		assertEquals(lg.generateLevel(),"You see a beach around you \n"+"Beyond that you see wolves \n");
	}
}
