public abstract class LevelGenerator
{	
	public abstract String generateLevel();

	public int calculateChallenge()
	{
		return 0;
	}

	public static void main(String[] args)
	{
		LevelGenerator lg = new WolfDecorator(new BeachLevel());
		System.out.println(lg.generateLevel());
	}
}
