public class TreasureDecorator extends LevelDecorator{

    public TreasureDecorator(LevelGenerator level)
    {
        this.level=level;
    }

    public String generateLevel()
    {
        return level.generateLevel() + "Beyond that you see treasure \n";
    }

    public int calculateChallenge()
    {
        return level.calculateChallenge() - 10;
    }

    public static void main(String[] args)
    {
        LevelGenerator lg = new TreasureDecorator(new WolfDecorator(new BeachLevel()));
        System.out.println(lg.generateLevel());
    }
}
