
public class ForestLevel extends LevelGenerator
{
	public ForestLevel()
	{
		
	}
	
	public String generateLevel()
	{
		return "You see a beach around you \n" + "You see a forest around you \n";
	}

	public int calculateChallenge()
	{
		return 20;
	}

	public static void main(String[] args)
	{
		LevelGenerator lg = new WolfDecorator(new ForestLevel());
		System.out.println(lg.generateLevel());
	}
}
