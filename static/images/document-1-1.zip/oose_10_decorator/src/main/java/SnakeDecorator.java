public class SnakeDecorator extends LevelDecorator{

    public SnakeDecorator(LevelGenerator level)
    {
        this.level=level;
    }

    public String generateLevel()
    {
        if(level instanceof BeachLevel)
        {
            return level.generateLevel() + "Beyond that you see a snake \n";
        }
        else if(level instanceof ForestLevel)
        {
            return "You see a beach around you \n" + level.generateLevel() + "Beyond that you see a snake \n";
        }
        else if(level instanceof DesertLevel)
        {
            return level.generateLevel() + "Beyond that you see a snake \n";
        }
        else
        {
            return "";
        }
    }

    public int calculateChallenge()
    {
        if(level instanceof BeachLevel)
        {
            return level.calculateChallenge() + 20;
        }
        else if(level instanceof ForestLevel)
        {
            return level.calculateChallenge() + 40;
        }
        else if(level instanceof DesertLevel)
        {
            return level.calculateChallenge() + 30;
        }
        else
        {
            return 0;
        }
    }

    public static void main(String[] args) {
        LevelGenerator lg = new TreasureDecorator(new SnakeDecorator(new WolfDecorator(new BeachLevel())));
        System.out.println(lg.generateLevel());
        System.out.println("Challenge: " + lg.calculateChallenge());
    }
}
