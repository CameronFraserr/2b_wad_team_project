public class DesertLevel extends LevelGenerator{

    public DesertLevel()
    {

    }


    public String generateLevel()
    {
        return "You see a desert around you \n";
    }

    public int calculateChallenge()
    {
        return 30;
    }

    public static void main(String[] args)
    {
        LevelGenerator lg = new WolfDecorator(new DesertLevel());
        System.out.println(lg.generateLevel());
    }
}
