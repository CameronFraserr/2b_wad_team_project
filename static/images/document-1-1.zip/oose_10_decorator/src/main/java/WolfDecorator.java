
public class WolfDecorator extends LevelDecorator
{
	public WolfDecorator(LevelGenerator level)
	{
		this.level=level;
	}
	
	public String generateLevel()
	{
		return "Beyond that you see wolves \n"+ level.generateLevel();
	}

	public int calculateChallenge()
	{
		return level.calculateChallenge() + 20;
	}

	public static void main(String[] args)
	{
		LevelGenerator lg = new WolfDecorator(new BeachLevel());
		System.out.println(lg.generateLevel());
	}


}
