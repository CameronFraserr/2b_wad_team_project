
public enum LEVEL_TYPE
{
	DESERT,FOREST,BEACH;
}
