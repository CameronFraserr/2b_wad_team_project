
public class BeachLevel extends LevelGenerator
{
	public BeachLevel()
	{
	}
	

	public String generateLevel()
	{
		return "You see a beach around you \n";
	}

	public int calculateChallenge()
	{
		return 10;
	}

	public static void main(String[] args)
	{
		LevelGenerator lg = new WolfDecorator(new BeachLevel());
		System.out.println(lg.generateLevel());
	}
}
